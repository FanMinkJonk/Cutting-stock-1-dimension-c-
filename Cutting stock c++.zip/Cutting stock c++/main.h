#ifndef __MAIN_H__
#define __MAIN_H__

#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <utility>

using namespace std;



#endif